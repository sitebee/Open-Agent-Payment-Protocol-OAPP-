# Open Agent Payment Protocol (OAPP) — Specification v0.1

## 1. Overview
OAPP is a document-based protocol for agentic commerce. It defines three mandate types:
- `intent` — human goals and constraints
- `cart` — agent proposal with itemised totals and evidence
- `payment` — scoped authorisation to execute the cart

Mandates are **portable JSON** with **Ed25519 detached signatures** and **hash chaining**.

## 2. Design Principles
- Human-first consent and readability
- Cryptographic integrity with Ed25519
- Minimum disclosure (use PSP tokens, not raw PAN)
- Replay resistance (nonces, expiries, idempotency)
- Transport-agnostic (webhooks, MQ, email, chat)
- Interoperable with existing rails (Stripe, A2A, AP2, ACP)

## 3. Data Model
Common envelope fields:
- `oapp_version` — semantic version (string)
- `type` — one of `intent|cart|payment`
- `*_id` — URL-safe identifier for the mandate
- `created_at` / `expires_at` — ISO timestamps
- `meta.prev_hash` — SHA-256 of the previous mandate JSON
- `sig` — detached JWS-like object (`alg`, `kid`, `jws`)

See JSON Schemas in `/spec/json-schema` for formal constraints.

## 4. Security
- **Signatures**: Ed25519 using libsodium/tweetnacl. Include `kid` a stable key identifier (e.g. DID key). Sign the canonical JSON (whitespace trimmed, stable key ordering).
- **Hash chain**: Each mandate carries the hash of the previous JSON to enforce ordering.
- **Replay**: Use `idempotency_key` and short expiries on payments.
- **Scope**: `constraints` and `payment_credential.scope` restrict spend, merchant, and reuse.

## 5. Transport
- HTTPS POST with `application/json`
- Retries must be idempotent
- All endpoints must require HTTPS and verify signatures

## 6. Mapping
- GA4 `items` -> OAPP `items`
- Stripe PaymentIntent ID -> `payment_credential.token`
- Shopify draft order -> `cart`

## 7. Error Model
Use RFC7807 problem+json:
```json
{ "type":"https://oapp.dev/errors/invalid", "title":"Invalid mandate", "status":400, "detail":"Signature missing", "instance":"req_123" }
```

## 8. Compatibility
OAPP is a **profile** that can wrap or translate to AP2 or ACP. Fields not present in OAPP can be attached in `meta` or extension namespaces.
