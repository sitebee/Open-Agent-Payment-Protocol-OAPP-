# Contributing to OAPP

Thanks for considering a contribution. Please open an issue to discuss proposals before submitting a PR.

## Areas that need help
- Additional adapters for PSPs and e-commerce platforms
- Security review and threat modelling
- Conformance test suite
- Example implementations in different languages

## Development
- Keep JSON minimal and human-readable
- Update JSON Schemas when changing fields
- Add tests and examples for new features
