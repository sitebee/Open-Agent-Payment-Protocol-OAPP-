# WooCommerce Adapter

Use REST API to create a pending order from OAPP `cart`. Confirm payment after `payment` mandate verification.
