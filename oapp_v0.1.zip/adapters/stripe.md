# Stripe Adapter

Map OAPP `payment_credential` to Stripe PaymentIntent.

- `kind: psp_token`, `psp: "Stripe"`, `token`: PaymentIntent ID
- `scope.max_amount` -> PaymentIntent amount cap (application logic)
- Execute by confirming PaymentIntent server-side after verifying signature.
