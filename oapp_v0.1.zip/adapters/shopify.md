# Shopify Adapter

Map OAPP `cart` to a Shopify draft order or checkout URL.

- Build a draft order from `items`
- Present checkout for human approval
- On approval, create PaymentIntent and produce `payment` mandate
