const typeEl = document.getElementById('type');
const idEl = document.getElementById('id');
const noteEl = document.getElementById('note');
const jsonEl = document.getElementById('json');

function base() {
  const now = new Date().toISOString();
  return {
    oapp_version: "0.1",
    type: typeEl.value,
    created_at: now,
    expires_at: new Date(Date.now() + 3600_000).toISOString(),
    meta: { prev_hash: null },
    sig: { alg: "ed25519", kid: "", jws: "" }
  };
}

function make() {
  const t = typeEl.value;
  const obj = base();
  if (t === 'intent') {
    obj.intent_id = idEl.value || 'int_demo';
    obj.actor = { role: "human", display_name: "Your Name" };
    obj.agent = { role: "ai_agent", name: "Your Agent" };
    obj.constraints = { max_total: { amount: 100, currency: "GBP" } };
    obj.preferences = { note: noteEl.value || "demo intent" };
  } else if (t === 'cart') {
    obj.cart_id = idEl.value || 'cart_demo';
    obj.intent_id = 'int_demo';
    obj.agent = { role: "ai_agent", name: "Your Agent" };
    obj.items = window.__items || [{
      sku: "SKU123",
      name: "Example item",
      qty: 1,
      unit_price: { amount: 9.99, currency: "GBP" }
    }];
    obj.totals = { grand_total: { amount: obj.items.reduce((a,i)=>a + (i.unit_price.amount * (i.qty||1)), 0), currency: "GBP" }};
    obj.human_approval = { status: "pending" };
  } else {
    obj.payment_id = idEl.value || 'pay_demo';
    obj.cart_id = 'cart_demo';
    obj.payer = { display_name: "Your Name" };
    obj.payment_credential = { kind: "psp_token", psp: "Stripe", token: "pi_xxx", scope: { single_use: true } };
    obj.execution = { return_url: "https://example.com/return", webhook_url: "https://example.com/hook", idempotency_key: "idem_demo" };
    obj.audit = { chain: [{ intent_id: "int_demo" }, { cart_id: "cart_demo" }] };
  }
  jsonEl.value = JSON.stringify(obj, null, 2);
}

document.getElementById('generate').onclick = make;
document.getElementById('addCommon').onclick = () => { noteEl.value = 'OAPP demo'; };
document.getElementById('addItem').onclick = () => {
  const item = { sku: "SKU" + Math.floor(Math.random()*1000), name: "New Item", qty: 1, unit_price: { amount: 19.99, currency: "GBP" } };
  window.__items = window.__items || [];
  window.__items.push(item);
  make();
};
document.getElementById('downloadJson').onclick = () => {
  const blob = new Blob([jsonEl.value || "{}"], { type: "application/json" });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = "oapp.json";
  a.click();
};
document.getElementById('copyJson').onclick = async () => {
  await navigator.clipboard.writeText(jsonEl.value || "{}");
  alert('Copied.');
};

make();
