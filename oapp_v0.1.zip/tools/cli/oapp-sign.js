#!/usr/bin/env node
import fs from 'fs';
import nacl from 'tweetnacl';
import yargs from 'yargs';
import { hideBin } from 'yargs/helpers';

const argv = yargs(hideBin(process.argv))
  .option('key', { type: 'string', demandOption: true })
  .option('in', { type: 'string', demandOption: true })
  .option('out', { type: 'string', demandOption: true })
  .argv;

const key = JSON.parse(fs.readFileSync(argv.key));
const data = JSON.parse(fs.readFileSync(argv.in));

// Canonicalise: stable key order and no whitespace beyond JSON.stringify defaults
const canonical = JSON.stringify(data);
const message = new Uint8Array(Buffer.from(canonical, 'utf8'));
const secret = new Uint8Array(Buffer.from(key.secretKey, 'base64'));
const sig = nacl.sign.detached(message, secret);
const jws = Buffer.from(sig).toString('base64');

data.sig = data.sig || { alg: 'ed25519' };
data.sig.alg = 'ed25519';
data.sig.kid = data.sig.kid || key.publicKey;
data.sig.jws = jws;

fs.writeFileSync(argv.out, JSON.stringify(data, null, 2));
console.log('Signed ->', argv.out);
