#!/usr/bin/env node
import fs from 'fs';
import nacl from 'tweetnacl';
import Ajv from 'ajv';
import path from 'path';
import url from 'url';

const __dirname = path.dirname(url.fileURLToPath(import.meta.url));
const base = path.resolve(__dirname, '../../..');

const file = process.argv[2];
if (!file) {
  console.error('Usage: node oapp-verify.js <file.json>');
  process.exit(1);
}
const data = JSON.parse(fs.readFileSync(file));

// Select schema
let schemaPath = '';
if (data.type === 'intent') schemaPath = path.join(base, 'spec/json-schema/intent.schema.json');
else if (data.type === 'cart') schemaPath = path.join(base, 'spec/json-schema/cart.schema.json');
else if (data.type === 'payment') schemaPath = path.join(base, 'spec/json-schema/payment.schema.json');
else {
  console.error('Unknown type:', data.type);
  process.exit(1);
}

const schema = JSON.parse(fs.readFileSync(schemaPath));

const ajv = new Ajv({ allErrors: true, strict: false });
const validate = ajv.compile(schema);
const valid = validate(data);

if (!valid) {
  console.error('Schema errors:', validate.errors);
  process.exit(1);
}

// Verify signature if present
if (data.sig && data.sig.jws && data.sig.alg === 'ed25519') {
  const pub = new Uint8Array(Buffer.from(data.sig.kid, 'base64'));
  const jws = new Uint8Array(Buffer.from(data.sig.jws, 'base64'));
  const canonical = JSON.stringify({ ...data, sig: { alg: data.sig.alg, kid: data.sig.kid, jws: data.sig.jws } });
  // For detached signature, verify against data with sig replaced by empty object would be typical;
  // for simplicity we verify against JSON with sig removed.
  const clone = { ...data };
  delete clone.sig;
  const message = new Uint8Array(Buffer.from(JSON.stringify(clone), 'utf8'));
  const ok = nacl.sign.detached.verify(message, jws, pub);
  if (!ok) {
    console.error('Signature invalid');
    process.exit(2);
  }
  console.log('Schema valid and signature valid.');
} else {
  console.log('Schema valid. No signature to verify.');
}
