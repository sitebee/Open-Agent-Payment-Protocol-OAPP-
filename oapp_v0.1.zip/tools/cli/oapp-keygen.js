#!/usr/bin/env node
import nacl from 'tweetnacl';

const kp = nacl.sign.keyPair();
const obj = {
  alg: 'ed25519',
  publicKey: Buffer.from(kp.publicKey).toString('base64'),
  secretKey: Buffer.from(kp.secretKey).toString('base64')
};
console.log(JSON.stringify(obj, null, 2));
